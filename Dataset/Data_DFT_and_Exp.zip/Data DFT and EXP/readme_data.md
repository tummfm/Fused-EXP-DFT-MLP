The folder DFT_data contains the samples for DFT training.

The folder Exp_data contains 
    1. the experiemtnal elastic contants derived from experimental lattice constants and the experimental elastic constant at a single termperature. 
    2. the boxes and atom positions for experimental lattices.
