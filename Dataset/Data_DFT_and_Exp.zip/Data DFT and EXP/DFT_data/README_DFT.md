This dataset consists of HCP, BCC, FCC Titanium structures. 
The dataset contains energy, forces, boxes, atom positions, and types.npy. The types array has 0's and 1's. It denotes whether a sample is taken from 
the Init dataset-0 or from the Bulk dataset-1. This is relevant as for DFT training the virial is considered only for the Init dataset.
